using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;


// =========================================================
// Mist���ʈꗗ
// =========================================================
public enum MistEffectType
{
    // Red
    HoleTrap,
    Shot,
    ColorBall,
    Bind,

    // Blue
    Protector,
    Analyzer,
    Counter,
    MistPlus,

    // Green
    MovePlus2,
    FlashBadge,
    PowerCake,
    RespawnCoffin,

    // Yellow
    UTurn,
    TimeBomb,
    MirrorPortal,
    MagnaTornado,

    // Black
    RandomEffect,
    Jackpot,
    Bug
}


// =========================================================
// �t�^��Ԃ̎��
// =========================================================
public enum StatusEffectType
{
    Bind,
    Protector,
    Counter,
    MistPlus,
    MovePlus2,
    PowerCake
}


// =========================================================
// �U����������
// =========================================================
public enum AttackResult
{
    NormalHit,
    BlockedByProtector,
    CounterHit,
    CounterBlocked
}


// =========================================================
// �t�^���1��
//
// List���̕��я����A���̂܂ܕt�^���ɂȂ�
// =========================================================
public class StatusEffectEntry
{
    public StatusEffectType type;
    public int value;

    public StatusEffectEntry(
        StatusEffectType type,
        int value
    )
    {
        this.type = type;
        this.value = value;
    }
}


// =========================================================
// Mist���ʃA�C�R��1��
// =========================================================
[System.Serializable]
public class MistEffectSpriteData
{
    public MistEffectType effect;
    public Sprite sprite;
}


public class MistEffectManager : MonoBehaviour
{
    // =========================================================
    // References
    // =========================================================

    [Header("References")]
    [SerializeField]
    private GameManager gameManager;

    [SerializeField]
    private BoardManager boardManager;


    // =========================================================
    // Mist Effect Icons
    // =========================================================

    [Header("Mist Effect Icons")]
    [SerializeField]
    private MistEffectSpriteData[] mistEffectSprites;


    // =========================================================
    // Hole Trap
    // =========================================================

    [Header("Hole Trap Visual")]
    [SerializeField]
    private GameObject holeMarkerPrefab;

    // Element 0 = 1P
    // Element 1 = 2P
    // Element 2 = 3P
    // Element 3 = 4P
    [SerializeField]
    private Sprite[] holeSprites;

    private readonly Dictionary<int, int>
        holeOwnerByPathIndex =
            new Dictionary<int, int>();

    private readonly Dictionary<int, GameObject>
        holeVisualsByPathIndex =
            new Dictionary<int, GameObject>();


    // =========================================================
    // Status UI
    // =========================================================

    [Header("Status UI")]
    [SerializeField]
    private Transform currentPlayerMistHolder;

    // Element 0 = 01.png
    // Element 1 = 02.png
    // ...
    // Element 9 = 10.png
    [SerializeField]
    private Sprite[] statusCountSprites;



    // =========================================================
    // Status Data
    //
    // List�̕��я� =
    // �u�t�^���ꂽ�^�C�~���O���������v
    // =========================================================

    private readonly List<StatusEffectEntry>[]
        playerStatusEffects =
    {
        new List<StatusEffectEntry>(),
        new List<StatusEffectEntry>(),
        new List<StatusEffectEntry>(),
        new List<StatusEffectEntry>()
    };


    // =========================================================
    // Mist���ʃA�C�R���擾
    // Analyzer UI����g�p
    // =========================================================

    public Sprite GetMistEffectSprite(
        MistEffectType effect
    )
    {
        if (mistEffectSprites == null)
            return null;

        for (int i = 0; i < mistEffectSprites.Length; i++)
        {
            MistEffectSpriteData data =
                mistEffectSprites[i];

            if (data == null)
                continue;

            if (data.effect != effect)
                continue;

            if (data.sprite == null)
            {
                Debug.LogWarning(
                    $"[MistEffect Icon] " +
                    $"{effect} ��Sprite���ݒ肳��Ă��܂���"
                );

                return null;
            }

            return data.sprite;
        }

        Debug.LogWarning(
            $"[MistEffect Icon] " +
            $"���ʃA�C�R�����o�^ : {effect}"
        );

        return null;
    }


    // =========================================================
    // Mist���ʒ��I
    //
    // Mist�擾����GameManager����Ă΂��
    // �g�p���ɂ͍Ē��I���Ȃ�
    // =========================================================

    public MistEffectType GetRandomEffectForColor(
        GameManager.MistColor color
    )
    {
        return GetRandomEffect(color);
    }


    // =========================================================
    // ���Ăяo���݊�
    // =========================================================

    public MistEffectType UseMist(
        GameManager.MistColor color,
        int playerIndex
    )
    {
        MistEffectType effect =
            GetRandomEffect(color);

        ExecuteEffect(
            effect,
            playerIndex
        );

        return effect;
    }


    // =========================================================
    // �F��Mist���ʒ��I
    // =========================================================

    MistEffectType GetRandomEffect(
    GameManager.MistColor color
)
    {
        switch (color)
        {
            // =================================================
            // Red
            // ���ݗL���F
            // HoleTrap / ColorBall
            // =================================================

            case GameManager.MistColor.Red:
                {
                    MistEffectType[] effects =
                    {
                MistEffectType.HoleTrap,

                // ��U���I�ΏۊO
                // MistEffectType.Shot,

                MistEffectType.ColorBall,

                // ��U���I�ΏۊO
                // MistEffectType.Bind
            };

                    return effects[
                        Random.Range(
                            0,
                            effects.Length
                        )
                    ];
                }


            // =================================================
            // Blue
            // ���ݗL���F
            // Protector / Analyzer
            // =================================================

            case GameManager.MistColor.Blue:
                {
                    MistEffectType[] effects =
                    {
                MistEffectType.Protector,
                MistEffectType.Analyzer,

                // ��U���I�ΏۊO
                // MistEffectType.Counter,
                // MistEffectType.MistPlus
            };

                    return effects[
                        Random.Range(
                            0,
                            effects.Length
                        )
                    ];
                }


            // =================================================
            // Green
            // ���ݗL���F
            // MovePlus2 / PowerCake
            // =================================================

            case GameManager.MistColor.Green:
                {
                    MistEffectType[] effects =
                    {
                MistEffectType.MovePlus2,

                // ��U���I�ΏۊO
                // MistEffectType.FlashBadge,

                MistEffectType.PowerCake,

                // ��U���I�ΏۊO
                // MistEffectType.RespawnCoffin
            };

                    return effects[
                        Random.Range(
                            0,
                            effects.Length
                        )
                    ];
                }


            // =================================================
            // Yellow
            // ���ݗL���F
            // UTurn / MagnaTornado
            // =================================================

            case GameManager.MistColor.Yellow:
                {
                    MistEffectType[] effects =
                    {
                MistEffectType.UTurn,

                // ��U���I�ΏۊO
                // MistEffectType.TimeBomb,
                // MistEffectType.MirrorPortal,

                MistEffectType.MagnaTornado
            };

                    return effects[
                        Random.Range(
                            0,
                            effects.Length
                        )
                    ];
                }


            // =================================================
            // Black
            // ����͍�Mist���̂�r�o���Ȃ�
            //
            // �����������邽�߃R�[�h�͎c���Ă���
            // =================================================

            case GameManager.MistColor.Black:
                {
                    MistEffectType[] effects =
                    {
                MistEffectType.RandomEffect,
                MistEffectType.Jackpot,
                MistEffectType.Bug
            };

                    return effects[
                        Random.Range(
                            0,
                            effects.Length
                        )
                    ];
                }
        }


        Debug.LogWarning(
            $"����`MistColor: {color}"
        );

        return MistEffectType.HoleTrap;
    }


    // =========================================================
    // �ۑ��ς�Mist���ʂ����s
    //
    // Analyzer�Ή���͂����炪������Mist�g�p���[�g
    // =========================================================

    public void ExecuteStoredEffect(
        MistEffectType effect,
        int playerIndex
    )
    {
        ExecuteEffect(
            effect,
            playerIndex
        );
    }


    // =========================================================
    // Mist���ʎ��s
    // =========================================================

    void ExecuteEffect(
        MistEffectType effect,
        int playerIndex
    )
    {
        switch (effect)
        {
            // =================================================
            // Red
            // =================================================

            case MistEffectType.HoleTrap:

                ActivateHole(
                    playerIndex
                );

                break;


            case MistEffectType.Shot:

                ActivateShot(
                    playerIndex
                );

                break;


            case MistEffectType.ColorBall:

                ActivateColorBall(
                    playerIndex
                );

                break;


            case MistEffectType.Bind:

                ActivateBind(
                    playerIndex
                );

                break;


            // =================================================
            // Blue
            // =================================================

            case MistEffectType.Protector:

                AddProtector(
                    playerIndex,
                    1
                );

                break;


            case MistEffectType.Analyzer:

                if (gameManager != null)
                {
                    gameManager.AnalyzeCurrentMists(
                        playerIndex
                    );
                }

                break;


            case MistEffectType.Counter:

                AddCounter(
                    playerIndex,
                    2
                );

                break;


            case MistEffectType.MistPlus:

                AddMistPlus(
                    playerIndex,
                    1
                );

                break;


            // =================================================
            // Green
            // =================================================

            case MistEffectType.MovePlus2:

                AddMovePlus2(
                    playerIndex,
                    1
                );

                break;


            case MistEffectType.FlashBadge:

                // TODO
                break;


            case MistEffectType.PowerCake:

                AddPowerCake(
                    playerIndex,
                    1
                );

                break;


            case MistEffectType.RespawnCoffin:

                // TODO
                break;


            // =================================================
            // Yellow
            // =================================================

            case MistEffectType.UTurn:

                if (gameManager != null)
                {
                    gameManager.ActivateUturn(
                        playerIndex
                    );
                }

                break;


            case MistEffectType.TimeBomb:

                // TODO
                break;


            case MistEffectType.MirrorPortal:

                // TODO
                break;


            case MistEffectType.MagnaTornado:

                if (gameManager != null)
                {
                    gameManager.ActivateMagnaTornado();
                }

                break;


            // =================================================
            // Black
            // =================================================

            case MistEffectType.RandomEffect:

                // TODO
                break;


            case MistEffectType.Jackpot:

                // TODO
                break;


            case MistEffectType.Bug:

                // TODO
                break;
        }
    }


    // =========================================================
    // Status����
    // =========================================================

    bool IsValidPlayerIndex(
        int playerIndex
    )
    {
        return
            playerIndex >= 0 &&
            playerIndex <
            playerStatusEffects.Length;
    }


    void AddStatus(
        int playerIndex,
        StatusEffectType type,
        int value
    )
    {
        if (!IsValidPlayerIndex(playerIndex))
            return;

        if (value <= 0)
            return;

        // �����֒ǉ�
        // List�̕��я� = �t�^��
        playerStatusEffects[
            playerIndex
        ].Add(
            new StatusEffectEntry(
                type,
                value
            )
        );

        RefreshAllStatusUI();
    }


    int GetStatusTotal(
        int playerIndex,
        StatusEffectType type
    )
    {
        if (!IsValidPlayerIndex(playerIndex))
            return 0;

        int total = 0;

        foreach (
            StatusEffectEntry status
            in playerStatusEffects[playerIndex]
        )
        {
            if (status.type != type)
                continue;

            total +=
                status.value;
        }

        return total;
    }


    // =========================================================
    // Bind
    // =========================================================

    public void AddBind(
        int playerIndex,
        int amount
    )
    {
        AddStatus(
            playerIndex,
            StatusEffectType.Bind,
            amount
        );
    }


    public int GetBindCount(
        int playerIndex
    )
    {
        return GetStatusTotal(
            playerIndex,
            StatusEffectType.Bind
        );
    }


    // =========================================================
    // Bind�F�ړ��g���K�[
    // =========================================================

    public int ApplyBindToMovement(
        int playerIndex,
        int moveAmount
    )
    {
        if (!IsValidPlayerIndex(playerIndex))
            return moveAmount;

        if (moveAmount <= 0)
            return moveAmount;

        List<StatusEffectEntry> list =
            playerStatusEffects[
                playerIndex
            ];

        int remainingMove =
            moveAmount;

        int i = 0;

        while (
            i < list.Count &&
            remainingMove > 0
        )
        {
            StatusEffectEntry status =
                list[i];

            if (
                status.type !=
                StatusEffectType.Bind
            )
            {
                i++;
                continue;
            }

            int consumed =
                Mathf.Min(
                    status.value,
                    remainingMove
                );

            status.value -=
                consumed;

            remainingMove -=
                consumed;

            if (status.value <= 0)
            {
                list.RemoveAt(i);
            }
            else
            {
                i++;
            }
        }

        RefreshAllStatusUI();

        return remainingMove;
    }


    // =========================================================
    // Protector
    // =========================================================

    public void AddProtector(
        int playerIndex,
        int amount
    )
    {
        AddStatus(
            playerIndex,
            StatusEffectType.Protector,
            amount
        );
    }


    public int GetProtectorCount(
        int playerIndex
    )
    {
        return GetStatusTotal(
            playerIndex,
            StatusEffectType.Protector
        );
    }


    // =========================================================
    // Protector�F�W�Q�g���K�[
    // =========================================================

    bool TryBlockInterference(
        int targetPlayerIndex,
        string effectName
    )
    {
        if (!IsValidPlayerIndex(targetPlayerIndex))
            return false;

        List<StatusEffectEntry> list =
            playerStatusEffects[
                targetPlayerIndex
            ];

        for (int i = 0; i < list.Count; i++)
        {
            StatusEffectEntry status =
                list[i];

            if (
                status.type !=
                StatusEffectType.Protector
            )
            {
                continue;
            }

            ConsumeOneFromStatus(
                targetPlayerIndex,
                i
            );

            RefreshAllStatusUI();

            return true;
        }

        return false;
    }


    void ConsumeOneFromStatus(
        int playerIndex,
        int listIndex
    )
    {
        List<StatusEffectEntry> list =
            playerStatusEffects[
                playerIndex
            ];

        if (
            listIndex < 0 ||
            listIndex >= list.Count
        )
        {
            return;
        }

        list[listIndex].value--;

        if (
            list[listIndex].value <= 0
        )
        {
            list.RemoveAt(
                listIndex
            );
        }
    }


    // =========================================================
    // Counter
    // =========================================================

    public void AddCounter(
        int playerIndex,
        int turns
    )
    {
        AddStatus(
            playerIndex,
            StatusEffectType.Counter,
            turns
        );
    }


    public int GetCounterTurns(
        int playerIndex
    )
    {
        return GetStatusTotal(
            playerIndex,
            StatusEffectType.Counter
        );
    }


    public bool HasCounter(
        int playerIndex
    )
    {
        return
            GetCounterTurns(
                playerIndex
            ) > 0;
    }


    // =========================================================
    // �U������
    //
    // �h�䑤�̏�Ԃ�t�^���ŎQ�Ƃ��A
    // �ŏ��Ƀg���K�[�֊Y��������Ԃ𔭓�
    // =========================================================

    public AttackResult ResolveAttack(
        int attackerPlayerIndex,
        int defenderPlayerIndex
    )
    {
        if (
            !IsValidPlayerIndex(
                attackerPlayerIndex
            ) ||
            !IsValidPlayerIndex(
                defenderPlayerIndex
            )
        )
        {
            return AttackResult.NormalHit;
        }

        List<StatusEffectEntry> defenderList =
            playerStatusEffects[
                defenderPlayerIndex
            ];

        for (
            int i = 0;
            i < defenderList.Count;
            i++
        )
        {
            StatusEffectEntry status =
                defenderList[i];

            switch (status.type)
            {
                // =============================================
                // Protector
                // =============================================

                case StatusEffectType.Protector:

                    ConsumeOneFromStatus(
                        defenderPlayerIndex,
                        i
                    );

                    RefreshAllStatusUI();

                    return
                        AttackResult.BlockedByProtector;


                // =============================================
                // Counter
                // =============================================

                case StatusEffectType.Counter:

                    bool counterBlocked =
                        TryBlockCounterAttack(
                            attackerPlayerIndex
                        );

                    RefreshAllStatusUI();

                    if (counterBlocked)
                    {
                        return
                            AttackResult.CounterBlocked;
                    }

                    return
                        AttackResult.CounterHit;


                // Bind / MistPlus�Ȃǂ�
                // ��U���g���K�[�ł͔������Ȃ�
                default:
                    continue;
            }
        }

        return AttackResult.NormalHit;
    }


    // =========================================================
    // Counter�����ɑ΂���Protector
    // =========================================================

    bool TryBlockCounterAttack(
        int targetPlayerIndex
    )
    {
        if (!IsValidPlayerIndex(targetPlayerIndex))
            return false;

        List<StatusEffectEntry> list =
            playerStatusEffects[
                targetPlayerIndex
            ];

        for (
            int i = 0;
            i < list.Count;
            i++
        )
        {
            StatusEffectEntry status =
                list[i];

            if (
                status.type !=
                StatusEffectType.Protector
            )
            {
                continue;
            }

            ConsumeOneFromStatus(
                targetPlayerIndex,
                i
            );

            return true;
        }

        return false;
    }


    // =========================================================
    // �v���C���[�̃^�[���I��
    // =========================================================

    public void OnPlayerTurnEnded(
        int playerIndex
    )
    {
        if (!IsValidPlayerIndex(playerIndex))
            return;

        TickTurnStatus(
            playerIndex,
            StatusEffectType.Counter
        );

        TickTurnStatus(
    playerIndex,
    StatusEffectType.MistPlus
);

        TickTurnStatus(
            playerIndex,
            StatusEffectType.MovePlus2
        );

        TickTurnStatus(
            playerIndex,
            StatusEffectType.PowerCake
        );

        RefreshAllStatusUI();
    }


    // =========================================================
    // �^�[���^��Ԃ�1�^�[�����炷
    //
    // �����Ԃ���������ꍇ�́A
    // �ł��Â�����1���������炷
    // =========================================================

    void TickTurnStatus(
        int playerIndex,
        StatusEffectType type
    )
    {
        if (!IsValidPlayerIndex(playerIndex))
            return;

        List<StatusEffectEntry> list =
            playerStatusEffects[
                playerIndex
            ];

        for (int i = 0; i < list.Count; i++)
        {
            StatusEffectEntry status =
                list[i];

            if (status.type != type)
                continue;

            status.value--;

            if (status.value <= 0)
            {
                list.RemoveAt(i);
            }

            break;
        }
    }


    // =========================================================
    // Red : HoleTrap
    // =========================================================

    void ActivateHole(
        int playerIndex
    )
    {
        if (
            boardManager == null ||
            boardManager.outerPath == null
        )
        {
            return;
        }

        List<int> candidates =
            new List<int>();

        for (
            int i = 0;
            i < boardManager.outerPath.Count;
            i++
        )
        {
            Vector2Int grid =
                boardManager.outerPath[i];

            // �p�͐ݒu�ΏۊO
            if (IsCorner(grid))
                continue;

            // ����Hole�͐ݒu�ΏۊO
            if (
                holeOwnerByPathIndex.ContainsKey(i)
            )
            {
                continue;
            }

            candidates.Add(i);
        }

        if (candidates.Count == 0)
            return;

        int holePathIndex =
            candidates[
                Random.Range(
                    0,
                    candidates.Count
                )
            ];

        holeOwnerByPathIndex[
            holePathIndex
        ] = playerIndex;

        CreateHoleVisual(
            holePathIndex,
            playerIndex
        );
    }


    public bool TryGetHoleOwner(
        int pathIndex,
        out int ownerPlayerIndex
    )
    {
        return
            holeOwnerByPathIndex.TryGetValue(
                pathIndex,
                out ownerPlayerIndex
            );
    }


    public void RemoveHole(
        int pathIndex
    )
    {
        holeOwnerByPathIndex.Remove(
            pathIndex
        );

        RemoveHoleVisual(
            pathIndex
        );
    }


    void CreateHoleVisual(
        int holePathIndex,
        int playerIndex
    )
    {
        if (
            holeMarkerPrefab == null ||
            boardManager == null
        )
        {
            return;
        }

        if (
            holeSprites == null ||
            playerIndex < 0 ||
            playerIndex >= holeSprites.Length ||
            holeSprites[playerIndex] == null
        )
        {
            return;
        }

        Vector2Int grid =
            boardManager.outerPath[
                holePathIndex
            ];

        Vector3 pos =
            boardManager.GridToWorld(
                grid.x,
                grid.y
            );

        pos.y =
            5.05f;

        GameObject marker =
            Instantiate(
                holeMarkerPrefab,
                pos,
                Quaternion.Euler(
                    90f,
                    0f,
                    0f
                )
            );

        SpriteRenderer sr =
            marker.GetComponent<SpriteRenderer>();

        if (sr == null)
        {
            Destroy(marker);

            Debug.LogWarning(
                "[HoleTrap] Prefab��SpriteRenderer������܂���"
            );

            return;
        }

        sr.sprite =
            holeSprites[playerIndex];

        holeVisualsByPathIndex[
            holePathIndex
        ] = marker;
    }


    void RemoveHoleVisual(
        int holePathIndex
    )
    {
        if (
            !holeVisualsByPathIndex.TryGetValue(
                holePathIndex,
                out GameObject marker
            )
        )
        {
            return;
        }

        if (marker != null)
        {
            Destroy(marker);
        }

        holeVisualsByPathIndex.Remove(
            holePathIndex
        );
    }


    bool IsCorner(
        Vector2Int grid
    )
    {
        int max =
            boardManager.gridSize - 1;

        return
            (grid.x == 0 || grid.x == max) &&
            (grid.y == 0 || grid.y == max);
    }


    // =========================================================
    // Red : Shot
    // =========================================================

    void ActivateShot(
        int attackerPlayerIndex
    )
    {
        if (gameManager == null)
            return;

        List<int> candidates =
            new List<int>();

        int playerCount =
            gameManager.GetPlayerCount();

        for (
            int i = 0;
            i < playerCount;
            i++
        )
        {
            if (i == attackerPlayerIndex)
                continue;

            if (
                gameManager.GetMistCount(i) <= 0
            )
            {
                continue;
            }

            candidates.Add(i);
        }

        if (candidates.Count == 0)
            return;

        int targetPlayerIndex =
            candidates[
                Random.Range(
                    0,
                    candidates.Count
                )
            ];

        if (
            TryBlockInterference(
                targetPlayerIndex,
                "Shot"
            )
        )
        {
            return;
        }

        int mistCount =
            gameManager.GetMistCount(
                targetPlayerIndex
            );

        int targetMistIndex =
            Random.Range(
                0,
                mistCount
            );

        gameManager.RemoveMist(
            targetPlayerIndex,
            targetMistIndex
        );
    }


    // =========================================================
    // Red : ColorBall
    // =========================================================

    void ActivateColorBall(
        int attackerPlayerIndex
    )
    {
        if (gameManager == null)
            return;

        List<int> candidates =
            new List<int>();

        int playerCount =
            gameManager.GetPlayerCount();

        for (
            int i = 0;
            i < playerCount;
            i++
        )
        {
            if (i == attackerPlayerIndex)
                continue;

            if (
                gameManager.GetMistCount(i) <= 0
            )
            {
                continue;
            }

            candidates.Add(i);
        }

        if (candidates.Count == 0)
            return;

        int targetPlayerIndex =
            candidates[
                Random.Range(
                    0,
                    candidates.Count
                )
            ];

        if (
            TryBlockInterference(
                targetPlayerIndex,
                "ColorBall"
            )
        )
        {
            return;
        }

        GameManager.MistColor newColor =
            (GameManager.MistColor)
            Random.Range(
                1,
                5
            );

        int mistCount =
            gameManager.GetMistCount(
                targetPlayerIndex
            );

        for (
            int i = 0;
            i < mistCount;
            i++
        )
        {
            gameManager.SetMistColor(
                targetPlayerIndex,
                i,
                newColor
            );
        }
    }


    // =========================================================
    // Red : Bind
    // =========================================================

    void ActivateBind(
        int attackerPlayerIndex
    )
    {
        if (gameManager == null)
            return;

        List<int> candidates =
            new List<int>();

        int playerCount =
            gameManager.GetPlayerCount();

        for (
            int i = 0;
            i < playerCount;
            i++
        )
        {
            if (i == attackerPlayerIndex)
                continue;

            candidates.Add(i);
        }

        if (candidates.Count == 0)
            return;

        int targetPlayerIndex =
            candidates[
                Random.Range(
                    0,
                    candidates.Count
                )
            ];

        if (
            TryBlockInterference(
                targetPlayerIndex,
                "Bind"
            )
        )
        {
            return;
        }

        AddBind(
            targetPlayerIndex,
            2
        );
    }


    // =========================================================
    // Status UI
    // =========================================================

    public void RefreshAllStatusUI()
    {
        if (gameManager == null)
            return;

        int playerIndex =
            gameManager.GetCurrentPlayerIndex();

        if (!IsValidPlayerIndex(playerIndex))
            return;

        RefreshStatusIcon(
            "BindStatus",
            GetMistEffectSprite(MistEffectType.Bind),
            GetBindCount(playerIndex)
        );

        RefreshStatusIcon(
            "ProtectorStatus",
            GetMistEffectSprite(MistEffectType.Protector),
            GetProtectorCount(playerIndex)
        );

        RefreshStatusIcon(
            "CounterStatus",
            GetMistEffectSprite(MistEffectType.Counter),
            GetCounterTurns(playerIndex)
        );

        RefreshStatusIcon(
            "MistPlusStatus",
            GetMistEffectSprite(MistEffectType.MistPlus),
            GetStatusTotal(
                playerIndex,
                StatusEffectType.MistPlus
            )
        );

        RefreshStatusIcon(
            "MovePlus2Status",
            GetMistEffectSprite(MistEffectType.MovePlus2),
            GetStatusTotal(
                playerIndex,
                StatusEffectType.MovePlus2
            )
        );

        RefreshStatusIcon(
            "PowerCakeStatus",
            GetMistEffectSprite(MistEffectType.PowerCake),
            GetPowerCakeTurns(playerIndex)
        );
    }

    // =========================================================
    // �݊����b�p�[
    // =========================================================

    public void RefreshBindUI()
    {
        RefreshAllStatusUI();
    }


    public void RefreshProtectorUI()
    {
        RefreshAllStatusUI();
    }


    public void RefreshCounterUI()
    {
        RefreshAllStatusUI();
    }


    void RefreshStatusIcon(
        string statusName,
        Sprite mainSprite,
        int count
    )
    {
        if (
            gameManager == null ||
            currentPlayerMistHolder == null
        )
        {
            return;
        }

        Transform oldStatus =
            currentPlayerMistHolder.Find(
                statusName
            );

        if (oldStatus != null)
        {
            Destroy(
                oldStatus.gameObject
            );
        }

        if (count <= 0)
            return;

        GameObject iconPrefab =
            gameManager.GetStatusIconPrefab();

        if (iconPrefab == null)
        {
            Debug.LogWarning(
                "[Status UI] Icon Prefab���ݒ肳��Ă��܂���"
            );

            return;
        }

        if (mainSprite == null)
        {
            Debug.LogWarning(
                $"[Status UI] {statusName} Sprite���ݒ肳��Ă��܂���"
            );

            return;
        }

        if (
            statusCountSprites == null ||
            statusCountSprites.Length == 0
        )
        {
            Debug.LogWarning(
                "[Status UI] Count Sprite���ݒ肳��Ă��܂���"
            );

            return;
        }

        int countSpriteIndex =
            Mathf.Clamp(
                count - 1,
                0,
                statusCountSprites.Length - 1
            );

        Sprite countSprite =
            statusCountSprites[
                countSpriteIndex
            ];

        GameObject icon =
            Instantiate(
                iconPrefab,
                currentPlayerMistHolder
            );

        icon.name =
            statusName;

        Image mainImage =
            icon.GetComponent<Image>();

        if (mainImage != null)
        {
            mainImage.sprite =
                mainSprite;

            mainImage.enabled =
                true;

            mainImage.color =
                Color.white;
        }

        Transform countTransform =
            icon.transform.Find(
                "Count"
            );

        if (countTransform == null)
        {
            Debug.LogWarning(
                $"[Status UI] " +
                $"{statusName} Prefab����Count������܂���"
            );

            return;
        }

        Image countImage =
            countTransform.GetComponent<Image>();

        if (countImage != null)
        {
            countImage.sprite =
                countSprite;

            countImage.enabled =
                true;

            countImage.color =
                Color.white;
        }
    }


    // =========================================================
    // Blue : MistPlus�i�A�g�������O�j
    // =========================================================

    public void AddMistPlus(
        int playerIndex,
        int turns
    )
    {
        AddStatus(
            playerIndex,
            StatusEffectType.MistPlus,
            turns
        );
    }


    public bool HasMistPlus(
        int playerIndex
    )
    {
        return
            GetStatusTotal(
                playerIndex,
                StatusEffectType.MistPlus
            ) > 0;
    }


    // =========================================================
    // Mist�����ʂ�MistPlus��K�p
    //
    // Mist�����C�x���g1��ɂ� +1
    // ��F
    // 1�l�� �� 2��
    // 2�l�� �� 3��
    // =========================================================

    public int ApplyMistPlus(
        int playerIndex,
        int baseAmount
    )
    {
        if (baseAmount <= 0)
            return baseAmount;

        if (!HasMistPlus(playerIndex))
            return baseAmount;

        return
            baseAmount + 1;
    }

    // =========================================================
    // Green : MovePlus2�i�~�j�G���W���j
    // =========================================================

    public void AddMovePlus2(
        int playerIndex,
        int turns
    )
    {
        AddStatus(
            playerIndex,
            StatusEffectType.MovePlus2,
            turns
        );
    }


    public bool HasMovePlus2(
        int playerIndex
    )
    {
        return
            GetStatusTotal(
                playerIndex,
                StatusEffectType.MovePlus2
            ) > 0;
    }


    // =========================================================
    // MovePlus2�F�ړ��� +2
    // =========================================================

    public int ApplyMovePlus2(
        int playerIndex,
        int moveAmount
    )
    {
        if (!IsValidPlayerIndex(playerIndex))
            return moveAmount;

        if (moveAmount <= 0)
            return moveAmount;

        if (!HasMovePlus2(playerIndex))
            return moveAmount;

        return moveAmount + 2;
    }
    // =========================================================
    // Green : PowerCake�i�p���[�P�[�L�j
    // =========================================================

    public void AddPowerCake(
        int playerIndex,
        int turns
    )
    {
        AddStatus(
            playerIndex,
            StatusEffectType.PowerCake,
            turns
        );
    }


    public int GetPowerCakeTurns(
        int playerIndex
    )
    {
        return GetStatusTotal(
            playerIndex,
            StatusEffectType.PowerCake
        );
    }
    // =========================================================
    // �ړ��nStatus��t�^���ɏ���
    //
    // Bind      = 1�ɂ� -1
    // MovePlus2 = +2
    // PowerCake = �~2
    //
    // playerStatusEffects �̐擪���珈�����邽��
    // ���̂܂܁u�t�^���ꂽ���v�ɂȂ�
    // =========================================================

    public int ApplyMovementStatuses(
        int playerIndex,
        int baseMoveAmount
    )
    {
        if (!IsValidPlayerIndex(playerIndex))
            return baseMoveAmount;

        if (baseMoveAmount <= 0)
            return baseMoveAmount;

        List<StatusEffectEntry> list =
            playerStatusEffects[playerIndex];

        int moveAmount =
            baseMoveAmount;

        for (int i = 0; i < list.Count; i++)
        {
            StatusEffectEntry status =
                list[i];

            switch (status.type)
            {
                // =====================================
                // Bind
                // =====================================
                case StatusEffectType.Bind:

                    if (moveAmount > 0)
                    {
                        int consumed =
                            Mathf.Min(
                                status.value,
                                moveAmount
                            );

                        moveAmount -= consumed;
                        status.value -= consumed;

                        if (status.value <= 0)
                        {
                            list.RemoveAt(i);
                            i--;
                        }
                    }

                    break;


                // =====================================
                // MovePlus2
                // =====================================
                case StatusEffectType.MovePlus2:

                    moveAmount += 2;

                    break;


                // =====================================
                // PowerCake
                // =====================================
                case StatusEffectType.PowerCake:

                    moveAmount *= 2;

                    break;
            }
        }

        RefreshAllStatusUI();

        return moveAmount;
    }
}